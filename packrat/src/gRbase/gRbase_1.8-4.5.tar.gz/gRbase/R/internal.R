#' @name internal
#' @aliases ggm  %>% MAT2ftM_ isGSD_glist solveSPD
#' 
NULL
