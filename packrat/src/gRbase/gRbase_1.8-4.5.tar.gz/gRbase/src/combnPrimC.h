#include "f2c.h"
int sla_combn__(int *nsel, int *ncand, int *list, int *j);
