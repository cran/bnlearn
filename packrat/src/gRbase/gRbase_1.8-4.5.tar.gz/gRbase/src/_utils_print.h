void printvecs(char **x, int *n);
void printveci(int *x, int *n);
void printvecd(double *x, int *n);
void printmati(int *Avec, int *nr, int *nc);
void printmatd(double *Avec, int *nr, int *nc);
