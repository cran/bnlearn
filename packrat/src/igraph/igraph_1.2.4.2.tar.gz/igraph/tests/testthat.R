library(testthat)
library(igraph)

suppressWarnings(RNGversion("3.5.0"))
test_check("igraph")
