/* $Id: dsexceptions.h,v 1.4 2009/06/03 01:10:56 ellson Exp $ $Revision: 1.4 $ */
/* vim:set shiftwidth=4 ts=8: */

#ifndef DSEXCEPTIONS_H_
#define DSEXCEPTIONS_H_

class Underflow { };
class Overflow  { };
class OutOfMemory { };
class BadIterator { };

#endif
